package com.partition.homework.odogemo;

import java.util.Arrays;
import java.util.List;

public class PlayHomeWorkApp {

	public static void main(String[] args) {
		List<Integer> numbers = Arrays.asList(1,2,3,4,5,6,7);
        int size=2;
        Homework homework = new Homework();
        System.out.println(homework.partition(numbers, size));

	}

}
