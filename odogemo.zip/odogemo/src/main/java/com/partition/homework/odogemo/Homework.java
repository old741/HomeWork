package com.partition.homework.odogemo;
import java.util.List;
import java.util.ArrayList;

public class Homework {

    public <T> List<List<T>> partition(List<T> list, int size){
           
               checkInput(list, size);
               List<List<T>> result = new  ArrayList<List<T>>();
               int listSize = (list.size() + size - 1) / size;
               int i=0;
              do{
                  checkSizeIndexInLoop(listSize, i);
                  int start = i * size;
                  int end = Math.min(start + size, list.size());
                  result.add(list.subList(start, end));
                  i++;
               }while(i<listSize);
           return  result;
       }
    
    private <T> void checkInput(List<T> list, int size) {
        if (list == null)
                 throw new NullPointerException(
                     "'list' must not be null");
               if (!(size > 0))
                 throw new IllegalArgumentException(
                     "'size' must be greater than 0");
    }    
    
    private void checkSizeIndexInLoop(int listSize, int index) {
        if (listSize < 0)
             throw new IllegalArgumentException("negative size: " + listSize);
        if (index < 0)
             throw new IndexOutOfBoundsException(
                 "index " + index + " must not be negative");
        if (index > listSize)
             throw new IndexOutOfBoundsException(
                 "index " + index + " must be less than size " + listSize);
    }

}


