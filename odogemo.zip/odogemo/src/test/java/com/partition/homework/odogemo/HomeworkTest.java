package com.partition.homework.odogemo;

import static org.junit.Assert.assertEquals;
import org.junit.Test;
import java.util.Arrays;
import java.util.List;


public class HomeworkTest {

	@Test
    public void testPartition() {
         List<Integer> numbers = Arrays.asList(1,2,3,4,5);
         int size=2;
         Homework homework = new Homework();
        assertEquals("[[1, 2], [3, 4], [5]]", homework.partition(numbers, size).toString());
    }
    
     @Test(expected=NullPointerException.class)
        public void partitionWithNullArray() {
         int size=2;
         Homework homework = new Homework();
         homework.partition(null, size);
        }
     
     @Test(expected=IllegalArgumentException.class)
        public void partitionWithIndexNegative() {
         List<Integer> numbers = Arrays.asList(1,2,3,4,5);
         int size=-2;
         Homework homework = new Homework();
         homework.partition(numbers, size);
        }
}
